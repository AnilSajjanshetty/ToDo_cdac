
import React, { useState } from 'react';
import formConfig from './FormConfig';
const DynamicForm = () => {
  const [formData, setFormData] = useState({});
  
  const handleInputChange = (fieldId, value) => {
    setFormData({
      ...formData,
      [fieldId]: value
    });
  };

  const renderFormField = (field) => {
    switch (field.type) {
      case 'text':
        return (
          <div key={field.id}>
            <label>{field.label}</label>
            <input
              type="text"
              placeholder={field.placeholder}
              onChange={(e) => handleInputChange(field.id, e.target.value)}
            />
          </div>
        );

      case 'radio':
        return (
          <div key={field.id}>
            <label>{field.label}</label>
            {field.options.map(option => (
              <div key={option.value}>
                <input
                  type="radio"
                  id={option.value}
                  name={field.id}
                  value={option.value}
                  onChange={() => handleInputChange(field.id, option.value)}
                />
                <label htmlFor={option.value}>{option.label}</label>
              </div>
            ))}
          </div>
        );

      case 'checkbox':
        return (
          <div key={field.id}>
            <label>{field.label}</label>
            {field.options.map(option => (
              <div key={option.value}>
                <input
                  type="checkbox"
                  id={option.value}
                  value={option.value}
                  onChange={(e) => handleInputChange(field.id, e.target.checked)}
                />
                <label htmlFor={option.value}>{option.label}</label>
              </div>
            ))}
          </div>
        );

      case 'dropdown':
        return (
          <div key={field.id}>
            <label>{field.label}</label>
            <select onChange={(e) => handleInputChange(field.id, e.target.value)}>
              <option value="">Select an option</option>
              {field.options.map(option => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div>
      <h2>Dynamic Form</h2>
      {formConfig.formFields.map(field => renderFormField(field))}
      <button onClick={() => console.log(formData)}>Submit</button>
    </div>
  );
};

export default DynamicForm;
