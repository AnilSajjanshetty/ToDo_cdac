import React from "react";
import DynamicForm from "./Form/DynamicForm"; 

const App = () => {
  return (
    <div>
      <h1>Form</h1>
      <DynamicForm />
    </div>
  );
};

export default App;
